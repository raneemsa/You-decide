# You decide
Udacity's final project.

You decide is an iOS app that allows users to visit virtual locations by adding pins to a [MKMapView](https://developer.apple.com/documentation/mapkit/mkmapview).
Once a user taps a pin the app fetches photos from [Flickr](https://www.flickr.com) for that location. As an extension of virtual tourist, "you decide" app allows the user to delete the pins he wants.

### Prerequisites

It was built using Xcode Version Version 9.2 (9C40b) along with Swift 4.
